#include "examples/test_cc_shared_library/bar2.h"

int bar2() { return 42; }
