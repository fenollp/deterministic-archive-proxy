#include "examples/test_cc_shared_library/a_suffix.h"

int a_suffix() { return 42; }
