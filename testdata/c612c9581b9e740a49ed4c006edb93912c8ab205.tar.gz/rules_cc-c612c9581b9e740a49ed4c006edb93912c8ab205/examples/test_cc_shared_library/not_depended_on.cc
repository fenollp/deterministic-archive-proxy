#include "examples/test_cc_shared_library/bar.h"

int foo() {
  bar();
  return 42;
}
