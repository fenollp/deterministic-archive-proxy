#include "examples/test_cc_shared_library/bar.h"

int bar() { return 42; }
