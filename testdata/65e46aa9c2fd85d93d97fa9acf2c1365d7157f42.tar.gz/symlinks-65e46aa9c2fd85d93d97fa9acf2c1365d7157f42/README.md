This repo shows that symlinks created with a relative path are well suited in Git, as they can be ported across machines.

Checkout the `wrong_symlink` branch for an example of symbolic link.

See http://www.mokacoding.com/blog/symliks-in-git/ for more details.
